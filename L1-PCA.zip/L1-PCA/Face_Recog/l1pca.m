
lv = 0;
while(lv ~= 1)
	clear all;
	clc;
    ls=[];
    display('This program tests the efficiency of Face recognition using Sparse representation');
        num_test=1;
 
        in_img = input('Enter template no from 1 to 38-');
        %in_img_1 = input('Enter template no from 1 to 38-');
        if ( (in_img < 1) && (in_img > 38))
                    display('Invalid option,quitting');
                    break;
        end
                in_img_no = input('Enter img no from 2 to 65-');
               % in_img_no_1 = input('Enter img no from 2 to 65-');
                display(ls);
                if ( (in_img < 2) && (in_img > 65))
                    display('Invalid option,quitting');
                    break;
                end
           
        
%	end
	%Training
			r=192;
			c=168;
			rec=zeros(1,2432);
			nrec=zeros(1,2432);
			addpath('C:\Users\vishe\Desktop\Face_Recog\Yale');
			if(num_test == 1)%1 training img 
				M=38;
				%Finding Basis
				A=[];
				for i=1:M
					img=strcat(int2str(i),'_33.jpg');
					a=imread(img);
					b=double(a);
					g=reshape(b,r*c,1);
					h=double(g);
					A=[A h];
				end
			else %3 training img
				M=38;			
				%Finding Basis
				A=[];
				for i=1:M
					img=strcat(int2str(i),'_33.jpg');
					a=imread(img);
					b=double(a);
					g=reshape(b,r*c,1);
					h=double(g);
					A=[A h];
					img=strcat(int2str(i),'_5.jpg');
					a=imread(img);
					b=double(a);
					g=reshape(b,r*c,1);
					h=double(g);
					A=[A h];
					img=strcat(int2str(i),'_47.jpg');
					a=imread(img);
					b=double(a);
					g=reshape(b,r*c,1);
					h=double(g);
					A=[A h];
				end
				M = 38*3;
			end					
		

		L=A'*(A);

		[vv dd]=eig(L);
		% Sort and eliminate those whose eigenvalue is zero
		v=[];
		d=[];
		for i=1:size(vv,2)
		if(dd(i,i)>1e-4)
		v=[v vv(:,i)];
		d=[d dd(i,i)];
		end
		end

		[B index]=sort(d);
		ind=zeros(size(index));
		dtemp=zeros(size(index));
		vtemp=zeros(size(v));
		len=length(index);
		for i=1:len
		dtemp(i)=B(len+1-i);
		ind(i)=len+1-index(i);
		vtemp(:,ind(i))=v(:,i);
		end
		d=dtemp;
		v=vtemp;
		% 
		%Normalization of eigenvectors
		for i=1:size(v,2) %access each column
		kk=v(:,i);
		temp=sqrt(sum(kk.^2));
		v(:,i)=v(:,i)./temp;
		end

		%Eigenvectors of C matrix
		u=[];
		for i=1:size(v,2)
		temp=sqrt(d(i));
		u=[u (A*v(:,i))./temp];
		end

		%Normalization of eigenvectors
		for i=1:size(u,2)
		kk=u(:,i);
		temp=sqrt(sum(kk.^2));
		u(:,i)=u(:,i)./temp;
		end

		% Find the weight of each face in the training set
		omega = [];
		for h=1:size(A,2)
		WW=[]; 
		for i=1:size(u,2)
		t = u(:,i)'; 
		WeightOfImage = dot(t,A(:,h)');
		WW = [WW; WeightOfImage];
		end
		omega = [omega WW];
		end
	%end
	

			
			img1=strcat(int2str(in_img),'_',int2str(in_img_no),'.jpg');
            %img2=strcat(int2str(in_img_1),'_',int2str(in_img_no_1),'.jpg');
			InputImage = imread(img1);
            InputImage1=InputImage;
            InputImage2=InputImage;
            InputImage3=InputImage;
            InputImage4=InputImage;
            %imshow(InputImage4);
            %InputImage1 = imread(img2);
            %img = uint8(repmat([zeros(20), 255*ones(20); 255*ones(20) zeros(20)], 5, 5));
            InputImage(1:100, 1:100) = imnoise(InputImage(1:100, 1:100), 'salt & pepper', 0.9);
            InputImage1(100:167, 100:167) = imnoise(InputImage1(100:167, 100:167), 'salt & pepper', 0.9);
            InputImage2(60:130, 60:130) = imnoise(InputImage2(60:130, 60:130), 'salt & pepper', 0.9);
            InputImage3(1:80, 60:140) = imnoise(InputImage3(1:80, 60:140), 'salt & pepper', 0.9);
            InputImage4(70:160, 1:80) = imnoise(InputImage4(70:160, 1:80), 'salt & pepper', 0.9);
            N=5;
            %imshow(InputImage4);
            my_im_cell = cell(N,1);
            my_im_cell{1} = InputImage;
            my_im_cell{2} = InputImage1;
            my_im_cell{3} = InputImage2;
            my_im_cell{4} = InputImage3;
            my_im_cell{5} = InputImage4;
            %InputImage=cat(1,I2, InputImage);
            display(my_im_cell)
		
	%	end
	%else % Check all faces
	%	if (ty == 1)%Eigenfaces
		
					ind = 1;index=1;
					for q = 1:length(my_im_cell)
							%img1=strcat(int2str(q),'_',int2str(p),'.jpg');
							InputImage = my_im_cell{q};
                            subplot (3,3,index)
                            imshow(InputImage);
							NormImage = reshape(InputImage,r*c,1); 

							p = [];
							aa=size(u,2);
							for i = 1:aa
							pare = dot(double(NormImage),u(:,i));
							p = [p; pare];
							end
							ReshapedImage = u(:,1:aa)*p; %m is the mean image, u is the eigenvector
							ReshapedImage = reshape(ReshapedImage,r,c);
							ReshapedImage = ReshapedImage';

							InImWeight = [];
							for i=1:size(u,2)
							t = u(:,i)';
							WeightOfInputImage = dot(t,double(NormImage'));
							InImWeight = [InImWeight; WeightOfInputImage];
							end

							% L1 Norm Minimization %
							x = omega \ InImWeight;
							if(num_test == 3)%3 training images
								u = [];
								for j=1:3:112
									l=(x(j)+x(j+1)+x(j+2))/3;
									u=[u l];
								end    
								[m i] = max(u);
							else%1 training image
								[m i] = max(x);
                            end
                            img2=strcat(int2str(i),'_33.jpg');
                            index=index+1;
							if i == q
								rec(ind) = 1;
							else
								nrec(ind) = 1;
							end
							ind = ind + 1;
					end
				%	end
					display('Success rate in percentage is-')
					100 - (sum(rec)/ind*100)
                    subplot (3,3,6)
				imshow(img2);
				

    lv = input('Enter 1 to quit, anything else to continue-');
    end